package pieces;
import game.*;

public class Pawn extends Piece {
	
	public Pawn(int x, int y, Player player, Board board){
		super(x, y, player, board);
	}
	
	// No board constructor.
	public Pawn(int x, int y, Player player){
		super(x, y, player);
	}
	
	@Override
	public String getIcon(){
		if (this.getColor() == "white")
			return "file:resources/white_pawn.png";
		else
			return "file:resources/black_pawn.png";
	}
	
	@Override
	public String toString(){
		return "Pawn (" + this.getPlayer().getColor() + ")";  
	}
	
	@Override
	public boolean isValidPath(int finalX, int finalY){
		int yDistance = this.getY() - finalY;
		int xDistance = Math.abs(this.getX() - finalX);
		
		if (this.getColor() == "white" && yDistance == -1 && this.getX() == finalX)
			return true;
		
		if (this.getColor() == "black" && yDistance == 1 && this.getX() == finalX)
			return true;
		
		if (this.getColor() == "white" && this.getY() == 1 && yDistance == -2)
			return true;
		
		if (this.getColor() == "black" && this.getY() == 6 && yDistance == 2)
			return true;
		
		//capturing this is technically a valid path.
		//this won't always be true, but we'll ensure that
		//the player isn't able to make any invalid moves
		//in a different method.
		if (this.getPlayer().getColor() == "white" && (yDistance == -1 && xDistance == 1))
			return true;
		
		if (this.getPlayer().getColor() == "black" && (yDistance == 1 && xDistance == 1))
			return true;
		
		return false;
	}
	
	@Override
	public int[][] drawPath(int finalX, int finalY){
		int steps = Math.abs(this.getY() - finalY);
		int[][] path = new int[2][steps];
		int currentY = this.getY();
		/**
		 * isValidPath method will check to make sure that 
		 * the path is valid before this method is 
		 * called. So, this logic works.
		 */
		for (int i=0; i < steps; i++){
			if (this.getColor() == "white")
				currentY++;
			else
				currentY--;

			path[0][i] = finalX;
			path[1][i] = currentY;
		}
		
		return path;
	}
}

package pieces;
import game.*;

public abstract class Piece {
	private int x, y;
	private Player player;
	private String icon;
	
	public Piece(int x, int y, Player player){
		this.x = x;
		this.y = y;
		this.player = player;
	}
	
	/**
	 * Piece constructor.
	 * @param x Piece's x coordinate
	 * @param y Piece's y coordinate
	 * @param player Player associated with the piece.
	 * @param board The board the piece is being placed on. By including
	 * the board we can avoid inconsistencies where the x and y values of the piece
	 * are not the same as the pieces coordinates on the actual board.
	 */
	public Piece(int x, int y, Player player, Board board){
		this.x = x;
		this.y = y;
		this.player = player;
		board.setPiece(this);
	}
	
	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
	
	public Player getPlayer(){
		return player;
	}
	
	public String getColor(){
		return this.getPlayer().getColor();
	}
	
	public abstract String getIcon();
	
	public void setX(int x){
		this.x = x;
	}
	
	public void setY(int y){
		this.y = y;
	}
	
	public void setCords(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public void setPlayer(Player newPlayer){
		this.player = newPlayer;
	}
	
	/**
	 * This method checks if a piece
	 * may move to a selected location on the board.
	 * It is abstract because we are not sure which piece we are
	 * selecting on the board, but every type of piece must be able to 
	 * be checked.
	 */
	public abstract boolean isValidPath(int finalX, int finalY);
	
	/**
	 * Returns the coordinates of the spaces that
	 * a piece moves along during it's path. 
	 * @param finalX x destination. Should be the final value in
	 * the first array.
	 * @param finalY y destination. Should be the final value in
	 * the second array.
	 * @return an array of length 2. The first element is an array
	 * of the x coordinates. The second is an array of y coordinates.
	 * path[0][3] = 3 path[1][3] = 2 means that the fourth space the
	 * piece lands on is (3, 2).
	 */
	public abstract int[][] drawPath(int finalX, int finalY);
}	


package pieces;
import game.*;

public class Knight extends Piece {
	
	public Knight(int x, int y, Player player, Board board){
		super(x, y, player, board);
	}
	
	/**
	 * No board constructor
	 */
	public Knight(int x, int y, Player player){
		super(x, y, player);
	}
	
	@Override
	public String getIcon(){
		if (this.getColor() == "white")
			return "file:resources/white_knight.png";
		else
			return "file:resources/black_knight.png";
	}
	
	@Override
	public String toString(){
		return "Knight (" + this.getPlayer().getColor() + ")";  
	}
	
	/**
	 * returns true if the absolute change
	 * in x is 2 and the absolute change in
	 * y is 1 or if the absolute change in x
	 * is 1 and the absolute change in y is 2.
	 */
	@Override
	public boolean isValidPath(int finalX, int finalY){
		int changeX = Math.abs(this.getX() - finalX);
		int changeY = Math.abs(this.getY() - finalY);
		
		if (changeX == 2 && changeY == 1 || changeX == 1 && changeY == 2)
			return true;
		
		return false;
	}
	
	@Override
	public int[][] drawPath(int finalX, int finalY){
		int[][] path = new int[2][1];
		
		/**
		 * The knight can jump over pieces. So, we are
		 * not very worried about the path it is taking.
		 */
		path[0][0] = finalX;
		path[1][0] = finalY;
		
		return path;
	}
	
	@Override
	public Piece copy(){
		return new Knight(this.getX(), this.getY(), this.getPlayer());
	}
}

package pieces;
import game.*;

public class Rook extends Piece{
	
	public Rook (int x, int y, Player player, Board board){
		super(x, y, player, board);
	}
	
	/**
	 * No board constructor
	 */
	public Rook (int x, int y, Player player){
		super(x, y, player);
	}
	
	@Override
	public String getIcon(){
		if (this.getColor() == "white")
			return "file:resources/white_rook.png";
		else
			return "file:resources/black_rook.png";
	}
	
	@Override
	public String toString(){
		return "Rook (" + this.getPlayer().getColor() + ")";  
	}
	
	/**
	 * Returns true if either the X or Y is unchanged.
	 */
	@Override
	public boolean isValidPath(int finalX, int finalY){
		//not moving is not a move.
		if (this.getX() == finalX && this.getY() == finalY)
			return false;
		
		if (this.getX() == finalX || this.getY() == finalY)
			return true;
		
		return false;
	}
	
	@Override
	public int[][] drawPath(int finalX, int finalY){
		int nSteps;
		
		//determines which axis is changing and by how much.
		if (this.getX() - finalX != 0)
			nSteps = Math.abs(this.getX() - finalX);
		else
			nSteps = Math.abs(this.getY() - finalY);
		
		int[][] path = new int[2][nSteps];
		
		int currentX = this.getX();
		int currentY = this.getY();
		
		for (int i=0; i < nSteps; i++){
			if (this.getX() - finalX < 0)
				currentX++;
			else if (this.getX() - finalX > 0)
				currentX--;
			
			if (this.getY() - finalY < 0)
				currentY++;
			else if (this.getY() - finalY > 0)
				currentY--;
			
			path[0][i] = currentX;
			path[1][i] = currentY;
		}
		
		return path;
	}
	
	@Override
	public Piece copy(){
		return new Rook(this.getX(), this.getY(), this.getPlayer());
	}
}

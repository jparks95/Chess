package pieces;
import game.*;

public class Bishop extends Piece {
	
	public Bishop(int x, int y, Player player, Board board){
		super(x, y, player, board);
	}
	
	/**
	 * No board constructor.
	 */
	public Bishop(int x, int y, Player player){
		super(x, y, player);
	}
	
	@Override
	public String getIcon(){
		if (this.getColor() == "white")
			return "file:resources/white_bishop.png";
		else
			return "file:resources/black_bishop.png";
	}
	
	@Override
	public String toString(){
		return "Bishop (" + this.getPlayer().getColor() + ")";  
	}
	
	/**
	 * Returns true if the piece is moving diagonally.
	 * Diagonal means that the absolute change in x is
	 * the same as the absolute change in y.
	 */
	@Override
	public boolean isValidPath(int finalX, int finalY){
		int changeX = Math.abs(this.getX() - finalX);
		int changeY = Math.abs(this.getY() - finalY);
		
		//Not moving is not valid.
		if (changeX == 0 && changeY == 0)
			return false;
		
		if (changeX == changeY)
			return true;
		
		return false;
	}
	
	@Override
	public int[][] drawPath(int finalX, int finalY){
		int nSteps = Math.abs(this.getX() - finalX);
		int[][] path = new int[2][nSteps];
		
		int currentX = this.getX();
		int currentY = this.getY();
		int step = 0;
		
		while (currentX != finalX && currentY != finalY){
			//determines which X direction is the piece moving.
			if (this.getX() - finalX < 0)
				currentX++;
			else
				currentX--;
			
			//determines which Y direction the piece is moving
			if (this.getY() - finalY < 0)
				currentY++;
			else
				currentY--;
			
			path[0][step] = currentX;
			path[1][step] = currentY;
			
			step++;
		}
		
		return path;
	}
	
	@Override
	public Piece copy(){
		return new Bishop(this.getX(), this.getY(), this.getPlayer());
	}
}

package pieces;
import game.*;

public class King extends Piece {
	
	public King(int x, int y, Player player, Board board){
		super(x, y, player, board);
	}
	
	/**
	 * No board constructor
	 */
	public King(int x, int y, Player player){
		super(x, y, player);
	}
	
	@Override
	public String getIcon(){
		if (this.getColor() == "white")
			return "file:resources/white_king.png";
		else
			return "file:resources/black_king.png";
	}
	
	@Override
	public String toString(){
		return "King (" + this.getPlayer().getColor() + ")";  
	}
	
	@Override
	public boolean isValidPath(int finalX, int finalY){
		int changeX = Math.abs(this.getX() - finalX);
		int changeY = Math.abs(this.getY() - finalY);
		
		//Not moving is not valid.
		if (changeX == 0 && changeY == 0)
			return false;
		
		if (changeX <= 1 && changeY <= 1)
			return true;
		
		return false;
	}
	
	@Override
	public int[][] drawPath(int finalX, int finalY){
		int[][] path = new int[2][1];
		
		/**
		 * The king can only move one space. Since
		 * we are checking if the path is valid,
		 * this logic is fine.
		 */
		path[0][0] = finalX;
		path[1][0] = finalY;
		
		return path;
	}
}

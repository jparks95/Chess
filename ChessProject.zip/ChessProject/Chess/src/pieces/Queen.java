package pieces;
import game.*;

public class Queen extends Piece {
	
	public Queen(int x, int y, Player player, Board board){
		super(x, y, player, board);
	}
	
	/**
	 * No board constructor
	 */
	public Queen(int x, int y, Player player){
		super(x, y, player);
	}
	
	@Override
	public String getIcon(){
		if (this.getColor() == "white")
			return "file:resources/white_queen.png";
		else
			return "file:resources/black_queen.png";
	}
	
	@Override
	public String toString(){
		return "Queen (" + this.getPlayer().getColor() + ")";  
	}
	
	@Override
	public boolean isValidPath(int finalX, int finalY){
		int xChange = Math.abs(this.getX() - finalX);
		int yChange = Math.abs(this.getY() - finalY);
		
		//not moving is not a move.
		if (xChange == 0 && yChange == 0)
			return false;
		
		if (this.getX() == finalX || this.getY() == finalY || (xChange == yChange))
			return true;
		
		return false;
	}
	
	@Override
	public int[][] drawPath(int finalX, int finalY){
		int[][] path;
		//created for rook and bishop constructor
		Player player = new Player("player", "player");
		
		//if the queen is moving like a rook.
		if (this.getX() == finalX || this.getY() == finalY){
			Rook rookMove = new Rook(this.getX(), this.getY(), player);
			path = rookMove.drawPath(finalX, finalY);
		}
		
		//else the queen is moving like a bishop.
		else{
			Bishop bishopMove = new Bishop(this.getX(), this.getY(), player);
			path = bishopMove.drawPath(finalX, finalY);
		}
		
		return path;
	}
	
	@Override
	public Piece copy(){
		return new Queen(this.getX(), this.getY(), this.getPlayer());
	}
}

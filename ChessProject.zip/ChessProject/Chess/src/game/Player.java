package game;

public class Player {
	private String color;
	private String name;
	
	public Player(String newName){
		this.name = newName;
	}
	
	//specify color constructor.
	public Player(String newColor, String newName){
		this.color = newColor;
		this.name = newName;
	}
	
	public String getColor(){
		return color;
	}
	
	public String getName(){
		return name;
	}
	
	public void setColor(String newColor){
		this.color = newColor;
	}
	
	public void setName(String newName){
		this.name = newName;
	}

}

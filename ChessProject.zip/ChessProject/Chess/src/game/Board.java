package game;
import java.util.Arrays;

import pieces.*;

public class Board {
	private Piece[][] boardArray;
	private King whiteKing;
	private King blackKing;
	private Piece[] whitePieces;
	private Piece[] blackPieces;
	
	/**
	 * This constructor synergizes with the piece constructor.
	 * In the piece constructor when a board is passed as an argument
	 * the new piece is automatically set on the board using the setPiece
	 * method. This ensures that a pieces x and y coordinates are consistent
	 * with it's true location. So, in this constructor we pass this board when we
	 * are creating the new pieces.
	 * @param whitePlayer passes the player1 argument to the pieces
	 * @param blackPlayer passes the player2 argument to the pieces
	 */
	public Board(Player whitePlayer, Player blackPlayer){
		this.boardArray = new Piece[8][8];
		this.whitePieces = new Piece[15];
		this.blackPieces = new Piece [15];
		
		//pawns
		for(int i=0; i < this.boardArray[1].length; i++){
			whitePieces[i] = new Pawn(i, 1, whitePlayer, this);
			blackPieces[i] = new Pawn(i, 6, blackPlayer, this);

		//white pieces
		whitePieces[8] = new Rook(0, 0, whitePlayer, this);
		whitePieces[9] = new Knight(1, 0, whitePlayer, this);
		whitePieces[10] = new Bishop(2, 0, whitePlayer, this);
		this.whiteKing = new King(3, 0, whitePlayer, this);
		whitePieces[11] = new Queen(4, 0, whitePlayer, this);
		whitePieces[12] = new Bishop(5, 0, whitePlayer, this);
		whitePieces[13] = new Knight(6, 0, whitePlayer, this);
		whitePieces[14] = new Rook(7, 0, whitePlayer, this);
		
		//black pieces
		blackPieces[8] = new Rook(0, 7, blackPlayer, this);
		blackPieces[9] = new Knight(1, 7, blackPlayer, this);
		blackPieces[10] = new Bishop(2, 7, blackPlayer, this);
		this.blackKing = new King(3, 7, blackPlayer, this);
		blackPieces[11] = new Queen(4, 7, blackPlayer, this);
		blackPieces[12] = new Bishop(5, 7, blackPlayer, this);
		blackPieces[13] = new Knight(6, 7, blackPlayer, this);
		blackPieces[14] = new Rook(7, 7, blackPlayer, this);
		}	
		
	}
	
	public Piece[][] getBoard(){
		return this.boardArray;
	}
	
	public void printBoard(){
		for (int i=0; i < this.boardArray.length; i++){
			System.out.println(Arrays.toString(boardArray[i]));
		}
	}
	
	/**
	 * Returns the piece at the given x and y coordinates.
	 */
	public Piece getPiece(int x, int y){
		return this.boardArray[y][x];
	}
	
	public King getWhiteKing(){
		return this.whiteKing;
	}
	
	public King getBlackKing(){
		return this.blackKing;
	}
	
	/**
	 * Places a piece on the board
	 * at it's X and Y values.
	 * @param piece specifies which piece object. gameBoard.getPiece(x, y).
	 */
	public void setPiece(Piece piece){
		this.boardArray[piece.getY()][piece.getX()] = piece;
	}
	
	/**
	 * Removes a piece from the board by setting it equal to null.
	 * @param piece 
	 */
	public void capturePiece(Piece piece){
		this.boardArray[piece.getY()][piece.getX()] = null;
		piece = null;
	}
	
	/**
	 * Checks to make sure that a move is valid on the board.
	 * This is different from isValidPath because it checks
	 * the move based on the current state of the board, where as isValidPath
	 * only checks to see if a piece can move like that.
	 * @param piece the starting piece. board.getPiece(x, y).
	 * @param finalX the x destination.
	 * @param finalY the y destination
	 * @return true if the piece can move, false if not.
	 */
	public boolean isValidMove(Piece piece, int finalX, int finalY, int turn){
		if ((piece.getColor() == "white" && turn % 2 != 0) || (piece.getColor() == "black" && turn %  2 != 1)){
			return false;
		}
		
		if (piece.isValidPath(finalX, finalY) == false)
			return false;
		
		//if a pawn is moving diagonally, there must be a enemy piece there.
		if (piece instanceof Pawn && piece.getX() != finalX && this.getPiece(finalX, finalY) == null)
			return false;
		
		//if a pawn is moving diagonally and there is a piece there, we must make sure it is an enemy.
		if (piece instanceof Pawn && piece.getX() != finalX && this.getPiece(finalX, finalY) != null){
			if (piece.getColor() == this.getPiece(finalX, finalY).getColor())
				return false;
		} 
		
		int[][] path = piece.drawPath(finalX, finalY);
		Piece currentStep;
		for (int i=0; i < path[0].length; i++){
			currentStep = this.getPiece(path[0][i], path[1][i]);
			//if null the spot is free.
			//we need to do this to avoid null pointer exceptions
			if (currentStep == null){
			}
			
			//if it is not null
			//if the piece is not null and it is not the last piece we cannot move there.
			else if (i != path[0].length - 1 && currentStep != null)
				return false;
			
			//if the last step has a piece of the same color we cannot move the piece there.
			else if (i == path[0].length - 1 && currentStep.getColor() == piece.getColor())
				return false;
		}
		
		return true;
	}
	
	/**
	 * Moves a piece to the specified location if it is a valid move.
	 * @param piece the piece that is being moved. board.getPiece(x, y).
	 * @param finalX x destination of the piece.
	 * @param finalY y destination of the piece.
	 */
	public void movePiece(Piece piece, int finalX, int finalY, int turn){
		if (this.isValidMove(piece, finalX, finalY, turn) == true){
			//this works because we are checking the color
			//of the piece isValidMove.
			if (this.getPiece(finalX, finalY) != null)
				this.capturePiece(piece);
			
			this.boardArray[finalY][finalX] = piece;
			this.boardArray[piece.getY()][piece.getX()] = null;
			piece.setCords(finalX, finalY);
		}
		else
			System.out.println("This move is invalid");
	}
	
	/**
	 * Loops through each enemy piece to see if 
	 * the piece has a valid move to the king.
	 * @param king that is being checked
	 * @param kingX X location of the king (we can obviously get this through the king, but we're checking spaces for isCheckMate
	 * @param kingY Y location of the king.
	 * @return
	 */
	public boolean isCheck(King king, int kingX, int kingY, int turn){
		Piece pieces[];
		if (king.getColor() == "white")
			pieces = this.blackPieces;
		else
			pieces = this.whitePieces;
		
			for (int i=0; i < pieces.length; i++){
				if (pieces[i] != null && this.isValidMove(pieces[i], kingX, kingY, turn) == true)
					return true;
		}
			return false;
	}
	
	/**
	 * isCheck with just the king argument.
	 * We needed the space arguments in the original
	 * so that we could use isCheck in isCheckMate.
	 * @param king
	 * @return
	 */
	public boolean isCheck(King king, int turn){
		return isCheck(king, king.getX(), king.getY(), turn);
	}
	
	/**
	 * Checks to see if either player has lost the game.
	 * This is where optimizing isCheck would be very useful.
	 *some of the code in this method may be useful to optimizing isCheck
	 * @return
	 */
	public boolean isCheckMate(King king, int turn){
		if (this.isCheck(king, turn) == false)
			return false;
		
		int x = king.getX() - 1;
		int y = king.getY() - 1;
		
		//check each space around the king, if they can move there without being in check then the
		//king is not in checkmate.
		for (int i=0; i < 2; i++){
			for(int j=0; j < 2; j++){
				if (this.isValidMove(king, x + i, y + j, turn) == true && this.isCheck(king, x+i, x+j, turn) == false)
					return false;
			}
		}
		
		return true;
	}
}

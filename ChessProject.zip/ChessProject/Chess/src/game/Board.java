package game;
import java.util.Arrays;

import pieces.*;

public class Board {
	private Piece[][] boardArray;
	private King whiteKing;
	private King blackKing;
	
	/**
	 * This constructor synergizes with the piece constructor.
	 * In the piece constructor when a board is passed as an argument
	 * the new piece is automatically set on the board using the setPiece
	 * method. This ensures that a pieces x and y coordinates are consistent
	 * with it's true location. So, in this constructor we pass this board when we
	 * are creating the new pieces.
	 * @param whitePlayer passes the player1 argument to the pieces
	 * @param blackPlayer passes the player2 argument to the pieces
	 */
	public Board(Player whitePlayer, Player blackPlayer){
		this.boardArray = new Piece[8][8];
		
		//pawns
		for(int i=0; i < this.boardArray[1].length; i++){
			new Pawn(i, 1, whitePlayer, this);
			new Pawn(i, 6, blackPlayer, this);

		//white pieces
		new Rook(0, 0, whitePlayer, this);
		new Knight(1, 0, whitePlayer, this);
		new Bishop(2, 0, whitePlayer, this);
		this.whiteKing = new King(3, 0, whitePlayer, this);
		new Queen(4, 0, whitePlayer, this);
		new Bishop(5, 0, whitePlayer, this);
		new Knight(6, 0, whitePlayer, this);
		new Rook(7, 0, whitePlayer, this);
		
		//black pieces
		new Rook(0, 7, blackPlayer, this);
		new Knight(1, 7, blackPlayer, this);
		new Bishop(2, 7, blackPlayer, this);
		this.blackKing = new King(3, 7, blackPlayer, this);
		new Queen(4, 7, blackPlayer, this);
		new Bishop(5, 7, blackPlayer, this);
		new Knight(6, 7, blackPlayer, this);
		new Rook(7, 7, blackPlayer, this);
		}		
	}
	
	//copies the current board to another board.
	public void copy(Board board){
		this.boardArray = board.copyBoard();
		this.whiteKing = (King) board.whiteKing.copy();
		this.blackKing = (King) board.blackKing.copy();
	}
	
	public Piece[][] copyBoard(){
		Piece[][] copyBoardArray = new Piece[8][8];
		for (int row=0; row < this.boardArray.length; row++){
			for (int col=0; col < this.boardArray[row].length; col++){
				if (this.boardArray[row][col] != null)
					copyBoardArray[row][col] = getPiece(col, row).copy();
			}
		}
		
		return copyBoardArray;
	}
	
	public Piece[][] getBoard(){
		return this.boardArray;
	}
	
	public void printBoard(){
		for (int i=0; i < this.boardArray.length; i++){
			System.out.println(Arrays.toString(boardArray[i]));
		}
	}
	
	public Piece getPiece(int x, int y){
		return this.boardArray[y][x];
	}
	
	public King getWhiteKing(){
		return this.whiteKing;
	}
	
	public King getBlackKing(){
		return this.blackKing;
	}
	
	public King getSameKing(Piece piece){
		if (piece.getColor() == "white")
			return this.whiteKing;
		else
			return this.blackKing;
	}
	
	public void setPiece(Piece piece){
		this.boardArray[piece.getY()][piece.getX()] = piece;
	}
	
	public void setKing(King king){
		if (king.getColor() == "white")
			this.whiteKing = king;
		else
			this.blackKing = king;
	}
	
	/**
	 * Removes a piece from the board by setting it equal to null.
	 * @param piece 
	 */
	public void capturePiece(Piece piece){
		this.boardArray[piece.getY()][piece.getX()] = null;
		piece = null;
	}
	
	/**
	 * Checks to make sure that a move is valid on the board.
	 * This is different from isValidPath because it checks
	 * the move based on the current state of the board, where as isValidPath
	 * only checks to see if a piece can move like that.
	 * @param piece the starting piece. board.getPiece(x, y).
	 * @param finalX the x destination.
	 * @param finalY the y destination
	 * @return true if the piece can move, false if not.
	 * NEED TO FIX IT SO PAWNS CANT CAPTURE FORWARD
	 */
	public boolean isValidMove(Piece piece, int finalX, int finalY, int turn){
		if (piece == null)
			return false;
		
		if ((piece.getColor() == "white" && turn % 2 != 0) || (piece.getColor() == "black" && turn %  2 != 1)){
			return false;
		}
		
		if (piece.isValidPath(finalX, finalY) == false)
			return false;
		
		//if a pawn is moving diagonally, there must be a enemy piece there.
		if (piece instanceof Pawn && piece.getX() != finalX && this.getPiece(finalX, finalY) == null)
			return false;
		
		//if a pawn is moving diagonally and there is a piece there, we must make sure it is an enemy.
		if (piece instanceof Pawn && piece.getX() != finalX && this.getPiece(finalX, finalY) != null){
			if (piece.getColor() == this.getPiece(finalX, finalY).getColor())
				return false;
		} 
		
		//A pawn cannot capture a piece that is two away from it.
		if (piece instanceof Pawn && piece.getX() != finalX && Math.abs((double) finalY - piece.getY()) == 2)
			return false;
		
		//A pawn cannot capture forward
		if (piece instanceof Pawn && finalX == piece.getX() && getPiece(finalX, finalY) != null && (Math.abs(finalY - piece.getY()) <= 2))
			return false;
		
		//if a King is in check it needs to do something about it.
		//recursive calls probably need to be addressed.
		//I should probably make a new class for these.
		//I think the issue here is that it gets stuck in an infinite loop and then can't 
		//get out of it. So, if I put this at the bottom we will know if the move is valid.
		
		int[][] path = piece.drawPath(finalX, finalY);
		Piece currentStep;
		for (int i=0; i < path[0].length; i++){
			currentStep = this.getPiece(path[0][i], path[1][i]);
			//if null the spot is free.
			//we need to do this to avoid null pointer exceptions
			if (currentStep == null){
			}
			
			//if it is not null
			//if the piece is not null and it is not the last piece we cannot move there.
			else if (i != path[0].length - 1 && currentStep != null)
				return false;
			
			//if the last step has a piece of the same color we cannot move the piece there.
			else if (i == path[0].length - 1 && currentStep.getColor() == piece.getColor())
				return false;
		}
		
		return true;
	}
	
	/**
	 * Keeps track of what the last move was.
	 */
	public Piece[] lastMove(Piece piece, int finalX, int finalY, int turn){
		Piece[] moves;
		
		if (this.getPiece(finalX, finalY) != null && this.getPiece(finalX, finalY).getColor() != piece.getColor())
			moves = new Piece[2];
		else
			moves = new Piece[1];
		
		System.out.println(piece);
		moves[0] = piece.copy();
		
		if (moves.length > 1){
			moves[1] = this.getPiece(finalX, finalY);
		}
		
		return moves;
	}
	
	public void returnMove(Piece[] moves, int finalX, int finalY){
		Piece piece = this.getPiece(finalX, finalY);
		this.boardArray[finalY][finalX] = null;
		piece = null;
		
		this.setPiece(moves[0]);
		
		if (moves.length > 1)
			this.setPiece(moves[1]);
	}
	
	/**
	 * Moves a piece to the specified location if it is a valid move.
	 * @param piece the piece that is being moved. board.getPiece(x, y).
	 * @param finalX x destination of the piece.
	 * @param finalY y destination of the piece.
	 */
	public void movePiece(Piece piece, int finalX, int finalY, int turn){
		//we don't need to check if it's a validMove for a few reasons:
		//1. we're going to do it anyways.
		//2. this method is more versatile if it doesn't check within this method.
		
		//this works because we are checking the color
		//of the piece isValidMove.
		if (this.getPiece(finalX, finalY) != null)
			this.capturePiece(getPiece(finalX, finalY));
			
		this.boardArray[finalY][finalX] = piece;
		this.boardArray[piece.getY()][piece.getX()] = null;
		
		if (piece instanceof King){
			if (piece.getColor() == "white")
				this.whiteKing.setCords(finalX, finalY);
			else
				this.blackKing.setCords(finalX, finalY);
		}
		
		piece.setCords(finalX, finalY);
	}
	
	
	/**
	 * Loops through each enemy piece to see if 
	 * the piece has a valid move to the king.
	 * @param king that is being checked
	 * @param kingX X location of the king (we can obviously get this through the king, but we're checking spaces for isCheckMate
	 * @param kingY Y location of the king.
	 * @return
	 * THERES SOMETHING WRONG WITH THIS BUT THE GAME WORKS WITHOUT IT!!
	 */
	public boolean isCheck(King king, int x, int y, int turn){
		for(int row=0; row < this.boardArray.length; row++){
			for(int col=0; col < this.boardArray[row].length; col++){
				Piece piece = getPiece(col, row);
				if(piece != null && piece.getColor() != king.getColor() && 
						isValidMove(piece, x, y, turn+1) == true){
					return true;
				}
			}
		}
		return false;
	}
	

}
	

package game;
import pieces.*;

import java.util.Scanner;

import javafx.scene.Scene;

public class Game {
	private Board gameBoard;
	private Player whitePlayer;
	private Player blackPlayer;
	private int turn;
	
	//private static int gameID;
	
	//randomly assigns the colors of the players on creation.
	public Game (Player player1, Player player2){
		coinFlip(player1, player2);
		if (player1.getColor() == "white"){
			this.whitePlayer = player1;
			this.blackPlayer = player2;
		}
		else {
			this.whitePlayer = player2;
			this.blackPlayer = player1;
		}
		
		this.gameBoard = new Board(this.whitePlayer, this.blackPlayer);
		this.turn = 0;
	}
	
	public Player getPlayer1(){
		return this.whitePlayer;
	}
	
	public Player getPlayer2(){
		return this.blackPlayer;
	}
	
	public Board getBoard(){
		return this.gameBoard;
	}
	
	public Piece[][] getBoardArray(){
		return this.gameBoard.getBoard();
	}
	
	public Piece getPiece(int row, int col){
		return this.getBoardArray()[row][col];
	}
	
	public int getTurn(){
		return this.turn;
	}
	
	public boolean isBlackCheckMate(){
		return this.gameBoard.isCheckMate(this.gameBoard.getBlackKing(), this.turn);
	}
	
	public boolean isWhiteCheckMate(){
		return this.gameBoard.isCheckMate(this.gameBoard.getWhiteKing(), this.turn);
	}
	
	public void incrementTurn(){
		this.turn++;
	}
	
	//Determines which color the players are assigned.
	public static void coinFlip(Player player1, Player player2){
		double coin = Math.random();
		if (coin >= .5){
			player1.setColor("white");
			player2.setColor("black");
		}
		else {
			player1.setColor("black");
			player2.setColor("white");
		}
	}
	
	//maybe this method is unnecessary
	//instead we have a "new game" button that does this
	//I think this has to be done in the GUI?
	public void startGame(){
	}
	
	
}

package game;
import java.util.Arrays;

import pieces.*;


public class Game {
	private Board gameBoard;
	private Player whitePlayer;
	private Player blackPlayer;
	private int turn;
	private Board copyBoard;
	
	//private static int gameID;
	
	//randomly assigns the colors of the players on creation.
	public Game (Player player1, Player player2){
		coinFlip(player1, player2);
		if (player1.getColor() == "white"){
			this.whitePlayer = player1;
			this.blackPlayer = player2;
		}
		else {
			this.whitePlayer = player2;
			this.blackPlayer = player1;
		}
		
		this.gameBoard = new Board(this.whitePlayer, this.blackPlayer);
		this.copyBoard = new Board(this.whitePlayer, this.blackPlayer);
		this.turn = 0;
	}
	
	public Player getPlayer1(){
		return this.whitePlayer;
	}
	
	public Player getPlayer2(){
		return this.blackPlayer;
	}
	
	public Board getBoard(){
		return this.gameBoard;
	}
	
	public Board getCopyBoard(){
		return this.copyBoard;
	}
	
	public Piece[][] getBoardArray(){
		return this.gameBoard.getBoard();
	}
	
	public Piece getPiece(int row, int col){
		return this.getBoardArray()[row][col];
	}
	
	public int getTurn(){
		return this.turn;
	}
	
	public King getKingTurn(){
		if (this.turn % 2 == 0)
			return this.gameBoard.getWhiteKing();
		else
			return this.gameBoard.getBlackKing();
	}
	
	public void incrementTurn(){
		this.turn++;
	}
	
	//Determines which color the players are assigned.
	public static void coinFlip(Player player1, Player player2){
		double coin = Math.random();
		if (coin >= .5){
			player1.setColor("white");
			player2.setColor("black");
		}
		else {
			player1.setColor("black");
			player2.setColor("white");
		}
	}
	
	/**
	 * Determines if a move puts the player in check.
	 * USE THE IS CHECK METHOD 
	 */
	public boolean isSuicide(Piece piece, int finalX, int finalY){
		this.copyBoard.copy(this.gameBoard);
		Piece moves[] = this.copyBoard.lastMove(piece, finalX, finalY, this.turn);
		this.copyBoard.movePiece(this.copyBoard.getPiece(piece.getX(), piece.getY()), finalX, finalY, this.turn);
		
		Piece copyPiece = this.copyBoard.getPiece(finalX, finalY);
		
		for (int row=0; row < this.copyBoard.getBoard().length; row++){
			for (int col=0; col < this.copyBoard.getBoard()[row].length; col++){
				Piece currPiece = this.copyBoard.getPiece(col, row);
				if (currPiece != null && this.copyBoard.isValidMove(currPiece, this.copyBoard.getSameKing(copyPiece).getX(), this.copyBoard.getSameKing(copyPiece).getY(), this.turn + 1) == true){
					return true;
				}
					
			}
		}
		
		//this.copyBoard.returnMove(moves, finalX, finalY);
		return false;
	}
	
	/**
	 * Checks how many possible moves a piece currently has in the game.
	 */
	public int[][] possibleMoves(Piece piece){
		int nMoves = 0;
		for (int row=0; row < this.gameBoard.getBoard().length; row++){
			for (int col=0; col < this.gameBoard.getBoard()[row].length; col++){
				if (this.gameBoard.isValidMove(piece, col, row, turn) == true && isSuicide(piece, col, row) == false)
					nMoves++;
			}
		}
		
		if (nMoves == 0)
			return null;
		
		int[][] moves = new int[2][nMoves];
		
		int n = 0;
		
		for (int row=0; row < this.gameBoard.getBoard().length; row++){
			for (int col=0; col < this.gameBoard.getBoard()[row].length; col++){
				if (this.gameBoard.isValidMove(piece, col, row, turn) == true && isSuicide(piece, col, row) == false){
					moves[0][n] = col;
					moves[1][n] = row;
					n++;
				}
			}
		}
		
		return moves;
	}
	
	public boolean isCheckMate(King king){
		if (this.gameBoard.isCheck(king, king.getX(), king.getY(), this.turn) == false)
			return false;
		
		System.out.println("We made it");
		
		for (int row=0; row < this.gameBoard.getBoard().length; row++){
			for (int col=0; col < this.gameBoard.getBoard()[row].length; col++){
				if (this.gameBoard.getPiece(col, row) != null && this.gameBoard.getPiece(col, row).getColor() == king.getColor() && 
						this.possibleMoves(this.getPiece(col, row)) != null){
						if (this.possibleMoves(this.getPiece(col, row))[0].length > 0){
							return false;
					}
				}
			}
		}
		
		return true;
	}
	
	public boolean confirmMove(Piece piece, int finalX, int finalY){
		if (this.gameBoard.isValidMove(piece, finalX, finalY, this.turn) == true && isSuicide(piece, finalX, finalY) == false)
			return true;
		else
			return false;
	}
}

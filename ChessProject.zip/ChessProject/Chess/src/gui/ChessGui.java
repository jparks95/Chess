package gui;

import game.*;

import javafx.application.Application;
import javafx.stage.Stage;

public class ChessGui extends Application{
	public static void main(String[] args) {
		launch(args);
	}
	
	public void start(Stage primaryStage) throws Exception{
		Player player1 = new Player("player1");
		Player player2 = new Player("player2");
		Game game = new Game(player1, player2);
		BoardGUI board = new BoardGUI(game, 600, 600);
		primaryStage.setScene(board.chessBoard());
		primaryStage.show();
	}
}
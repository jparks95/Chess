package gui;
import java.util.Arrays;

import game.*;

import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class ChessGui extends Application{
	public static void main(String[] args) {
		launch(args);
	}
	
	public void start(Stage primaryStage) throws Exception{
		Player player1 = new Player("player1");
		Player player2 = new Player("player2");
		Game game = new Game(player1, player2);
		BoardGUI board = new BoardGUI(game, 600, 600);
		primaryStage.setScene(board.chessBoard());
		primaryStage.show();
	}
}
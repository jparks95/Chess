package gui;

import game.Game;
import pieces.*;
import game.Player;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class BoardGUI{
	private Scene boardScene;
	private Game game;
	private StackPane[][] spaces = new StackPane[8][8];
	private int sourceRow;
	private int sourceCol;
	private int sceneWidth;
	private int sceneHeight;
	private boolean selected = false;
	private StackPane selectedSpace;
	
	public BoardGUI(Game game, int screenWidth, int screenHeight){
		this.game = game;
		this.sceneWidth = screenWidth;
		this.sceneHeight = screenHeight;
		this.boardScene = chessBoard();
	}
	
	//the issues stem from the images.
	public Scene chessBoard() {	
		Scene chessBoard;
		GridPane grid = new GridPane();
		final int size = 8;
		//creates the board.
		for (int row = 0; row < size; row++){
			for (int col = 0; col < size; col++){
				StackPane space = new StackPane();
				Rectangle rec = new Rectangle(sceneWidth / 8, sceneHeight / 8);
				setColor(row, col, rec);
				space.getChildren().add(rec);
				//adds the images to the spaces.
				setImages(row, col, space);
				spaces[row][col] = space;
				setSpaceMouseEvent(space);
				grid.add(space, col, row);
			}
		}
		
		chessBoard = new Scene(grid, this.sceneWidth, this.sceneHeight);
		return chessBoard;
	}
	
	//returns an array of all the spaces on the board.
	public StackPane[][] getSpaces(){
		return this.spaces;
	}
	
	//returns an array of a specific space on the board.
	public StackPane getSpace(int row, int col){
		return this.spaces[row][col];
	}
	
	//returns the rectangle that is occupying the space.
	public Rectangle getSpaceRec(StackPane space){
		return (Rectangle) space.getChildren().get(0);
	}
	
	public String getImageString(int row, int col){
		return this.game.getBoard().getPiece(col, row).getIcon();
	}
	
	public Piece getPiece(){
		return this.game.getBoard().getPiece(this.sourceCol, this.sourceRow);
	}
	
	public int getLocation(double cord){
		double spaceHeight = this.sceneHeight / 8;
		return (int) (cord / spaceHeight);
	}
	
	public boolean isValidMove(int x, int y){
		//makes sure that the original space actually has a piece on it.
		if (this.game.getBoardArray()[this.sourceRow][this.sourceCol] == null){
			return false;
		}
		return this.game.getBoard().isValidMove(getPiece(), x, y, this.game.getTurn());
	}
	
	//sets the source row based on where the used clicked.
	public void setSourceRow(double yCord){
		double spaceHeight = this.sceneHeight / 8;
		this.sourceRow = (int) (yCord / spaceHeight);
	}
	
	public void setSourceCol(double xCord){
		double spaceWidth = this.sceneWidth / 8;
		this.sourceCol = (int) (xCord / spaceWidth);
	}
	
	//sets the color of the space on the chess board's initialization.
	public static void setColor(int row, int col, Rectangle rec){
		if ((row + col) % 2 == 0)
			rec.setFill(Color.ALICEBLUE);
		else
			rec.setFill(Color.BLACK);
	}
	
	//sets the images in the board initialization.x
	public void setImages(int row, int col, StackPane space){
		if (row == 0 || row == 1 || row == 6 || row == 7){
			Image img = new Image(getImageString(row, col));
			ImageView imgV = new ImageView(img);
			imgV.setFitWidth(sceneWidth / 8);
			imgV.setFitHeight(sceneHeight / 8);
			space.getChildren().add(imgV);
		}
	}
	
	//sets up the mouse event for the spaces.
	public void setSpaceMouseEvent(StackPane space){
		space.setOnMouseClicked(e -> {
			if (this.selected == false){
				this.selectedSpace = space;
				//sets the source row and col based on the initial click.
				setSourceRow(e.getSceneY());
				setSourceCol(e.getSceneX());
				//highlights which space was selected.
				getSpaceRec(space).setFill(Color.LIME);
				this.selected = true;
			} else {
				//if the clicked on space is a valid move.
				if (isValidMove(getLocation(e.getSceneX()), getLocation(e.getSceneY())) == true){
					//if the space doesn't have anything there already.
					if (space.getChildren().size() == 1 && this.selectedSpace.getChildren().size() == 2){
						space.getChildren().add(selectedSpace.getChildren().get(1));
//						this.selectedSpace.getChildren().remove(1);
						this.game.getBoard().movePiece(this.getPiece(), this.getLocation(e.getSceneX()), this.getLocation(e.getSceneY()), this.game.getTurn());
					} else {
						space.getChildren().remove(1);
						space.getChildren().add(selectedSpace.getChildren().get(1));
						this.game.getBoard().movePiece(this.getPiece(), this.getLocation(e.getSceneX()), this.getLocation(e.getSceneY()), this.game.getTurn());
					}
					this.game.incrementTurn();
				}
				//sets the space rectangle back to the original value after the second click.
				setColor(this.sourceRow, this.sourceCol, getSpaceRec(selectedSpace));
				this.selected = false;
			}
			
			e.consume();
		});
	}

}

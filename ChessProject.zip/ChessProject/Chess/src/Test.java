import java.util.Arrays;
import pieces.*;
import game.*;

public class Test {
	int[] n;
	
	public Test(int[] t2){
		this.n = t2;
	}
	
	public Test(Test another){
		this.n = another.n.clone();
	}

	public static void main(String[] args) {
		Player p1 = new Player("white", "p1");
		Player p2 = new Player("black", "p2");
		Player p3 = new Player("white", "p3");
		Player p4 = new Player("black", "p4");
		Board b = new Board(p1, p2);
		Board b2 = new Board(p3, p3);
		b2.copy(b);
		System.out.println(b == b2);
		
		Pawn pawn = new Pawn(2, 1, p3);
		Piece[] moves = {pawn};
		b2.movePiece(b2.getPiece(2, 1), 2, 2, 0);
		b2.printBoard();
		b2.returnMove(moves, 2, 2);
		b2.printBoard();
		b2.movePiece(b2.getPiece(2, 1), 2, 2, 0);
		b2.printBoard();
		b2.isValidMove(null, 5, 2, 0);
	}

}